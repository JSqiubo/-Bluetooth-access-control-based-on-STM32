#ifndef __SWITCH_H
#define __SWITCH_H	 
#include "sys.h"

#define SWITCH0 PGout(2)// PG2
#define SWITCH1 PGout(4)// PG4
#define SWITCH2 PGout(6)// PG6
#define SWITCH3 PGout(8)// PG8

void SWITCH_Init(void);//��ʼ��

		 				    
#endif
